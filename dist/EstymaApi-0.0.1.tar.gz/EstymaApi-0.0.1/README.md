Wrapper for the EstymaApi Heating Systems

This is a work in progess and will only include readind stuff from the api.
Im building this to integrate our heating system into home assistant.

https://github.com/Tabisch/Igneo_ha_integration